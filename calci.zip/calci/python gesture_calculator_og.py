import cv2
import numpy as np
import track_hand as htm
import time
import re

# Camera Setup
wCam, hCam = 1280, 720
cap = cv2.VideoCapture(0)
cap.set(3, wCam)
cap.set(4, hCam)

# Hand Detector
detector = htm.handDetector(detectionCon=0.7, maxHands=2)

# Variables
expression = ""
last_input_time = 0
debounce_delay = 1  # seconds
result = ""
prev_gesture = None

def is_valid_expression(expr):
    """Check if the expression is mathematically valid"""
    try:
        # Basic validation - allow only numbers and +-*/ operators
        if not re.match(r'^[\d+\-*/.]+$', expr):
            return False
        
        # Check for division by zero
        if '/0' in expr:
            return False
            
        # Check for invalid operator sequences
        if any(op in expr for op in ['++', '--', '**', '//', '*/', '/*']):
            return False
            
        return True
    except:
        return False

def get_gesture(hands_data):
    if len(hands_data) == 0:
        return None
    
    # Single hand gestures
    if len(hands_data) == 1:
        fingers = hands_data[0]['fingers']
        
        if fingers == [0, 0, 0, 0, 0]: return "0"
        elif fingers == [0, 1, 0, 0, 0]: return "1"
        elif fingers == [0, 1, 1, 0, 0]: return "2"
        elif fingers == [0, 1, 1, 1, 0]: return "3"
        elif fingers == [0, 1, 1, 1, 1]: return "4"
        elif fingers == [1, 1, 1, 1, 1]: return "5"
        elif fingers == [1, 0, 0, 0, 1]: return "+"
        elif fingers == [0, 1, 1, 0, 1]: return "-"
        elif fingers == [1, 1, 0, 0, 1]: return "*"
        elif fingers == [0, 0, 0, 0, 1]: return "/"
        elif fingers == [0, 0, 1, 0, 0]: return "="
        elif fingers == [0, 0, 0, 1, 0]: return "C"
    
    # Two hands gestures (6-9)
    elif len(hands_data) == 2:
        total_fingers = sum(hands_data[0]['fingers']) + sum(hands_data[1]['fingers'])
        if 6 <= total_fingers <= 9:
            return str(total_fingers)
    
    return None

while True:
    success, img = cap.read()
    if not success:
        print("Failed to capture image")
        continue
        
    img = detector.findHands(img)
    hands_data = detector.getMultiHandData(img)
    
    # Draw bounding boxes
    for hand in hands_data:
        xmin, ymin, xmax, ymax = hand['bbox']
        cv2.rectangle(img, (xmin-20, ymin-20), (xmax+20, ymax+20), (0, 255, 0), 2)
    
    gesture = get_gesture(hands_data)
    
    current_time = time.time()
    if gesture and gesture != prev_gesture:
        if (current_time - last_input_time) > debounce_delay:
            if gesture == "=":
                try:
                    if is_valid_expression(expression):
                        # Use float division and round to 2 decimal places
                        result = str(round(eval(expression), 2))
                        expression = result
                    else:
                        result = "Error"
                except:
                    result = "Error"
                    expression = ""
            elif gesture == "C":
                expression = ""
                result = ""
            else:
                # Prevent multiple operators in sequence
                if expression and expression[-1] in '+-*/' and gesture in '+-*/':
                    expression = expression[:-1] + gesture
                else:
                    expression += gesture
            prev_gesture = gesture
            last_input_time = current_time

    # Display information
    cv2.putText(img, f"Expression: {expression}", (50, 50),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
    cv2.putText(img, f"Result: {result}", (50, 100),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    cv2.putText(img, f"Hands: {len(hands_data)}", (50, 150),
               cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
    
    if gesture:
        cv2.putText(img, f"Gesture: {gesture}", (50, 200),
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

    cv2.imshow("Gesture Calculator", img)
    key = cv2.waitKey(1) & 0xFF
    if key == ord('q') or key == 27:
        break

cap.release()
cv2.destroyAllWindows()