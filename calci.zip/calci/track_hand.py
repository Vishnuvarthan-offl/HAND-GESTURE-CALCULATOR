import cv2
import mediapipe as mp
import math

class handDetector():
    def __init__(self, mode=False, maxHands=2, modelComplexity=1, detectionCon=0.5, trackCon=0.5):
        self.mode = mode
        self.maxHands = maxHands
        self.modelComplex = modelComplexity
        self.detectionCon = detectionCon
        self.trackCon = trackCon
        
        self.mpHands = mp.solutions.hands
        self.hands = self.mpHands.Hands(
            self.mode,
            self.maxHands,
            self.modelComplex,
            self.detectionCon,
            self.trackCon
        )
        self.mpDraw = mp.solutions.drawing_utils
        self.tipIds = [4, 8, 12, 16, 20]
        self.lmList = []
        self.handTypes = []

    def findHands(self, img, draw=True):
        imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        self.results = self.hands.process(imgRGB)
        self.handTypes = []
        
        if self.results.multi_hand_landmarks:
            for handType, handLms in zip(self.results.multi_handedness, self.results.multi_hand_landmarks):
                self.handTypes.append(handType.classification[0].label)
                if draw:
                    self.mpDraw.draw_landmarks(img, handLms, self.mpHands.HAND_CONNECTIONS)
        return img

    def findPosition(self, img, handNo=0, draw=True):
        xList = []
        yList = []
        bbox = []
        self.lmList = []
        
        if self.results.multi_hand_landmarks and len(self.results.multi_hand_landmarks) > handNo:
            myHand = self.results.multi_hand_landmarks[handNo]
            for id, lm in enumerate(myHand.landmark):
                h, w, c = img.shape
                cx, cy = int(lm.x * w), int(lm.y * h)
                xList.append(cx)
                yList.append(cy)
                self.lmList.append([id, cx, cy])
                if draw:
                    cv2.circle(img, (cx, cy), 5, (255, 0, 255), cv2.FILLED)

            xmin, xmax = min(xList), max(xList)
            ymin, ymax = min(yList), max(yList)
            bbox = xmin, ymin, xmax, ymax

            if draw:
                cv2.rectangle(img, (xmin - 20, ymin - 20), (xmax + 20, ymax + 20),
                              (0, 255, 0), 2)
                
        return self.lmList, bbox

    def fingersUp(self, handNo=0):
        fingers = []
        if len(self.handTypes) > handNo and self.results.multi_hand_landmarks:
            myHand = self.results.multi_hand_landmarks[handNo]
            
            # Thumb (different for left/right hand)
            if self.handTypes[handNo] == "Right":
                if myHand.landmark[self.tipIds[0]].x > myHand.landmark[self.tipIds[0]-1].x:
                    fingers.append(1)
                else:
                    fingers.append(0)
            else:
                if myHand.landmark[self.tipIds[0]].x < myHand.landmark[self.tipIds[0]-1].x:
                    fingers.append(1)
                else:
                    fingers.append(0)
            
            # Other fingers
            for id in range(1, 5):
                if myHand.landmark[self.tipIds[id]].y < myHand.landmark[self.tipIds[id]-2].y:
                    fingers.append(1)
                else:
                    fingers.append(0)
                    
        return fingers

    def getMultiHandData(self, img):
        handsData = []
        if self.results.multi_hand_landmarks:
            for i, (handType, handLms) in enumerate(zip(self.results.multi_handedness, self.results.multi_hand_landmarks)):
                hand = {
                    'type': handType.classification[0].label,
                    'lmList': [],
                    'bbox': [],
                    'fingers': self.fingersUp(i)
                }
                
                xList = []
                yList = []
                for id, lm in enumerate(handLms.landmark):
                    h, w, c = img.shape
                    cx, cy = int(lm.x * w), int(lm.y * h)
                    hand['lmList'].append([id, cx, cy])
                    xList.append(cx)
                    yList.append(cy)
                
                xmin, xmax = min(xList), max(xList)
                ymin, ymax = min(yList), max(yList)
                hand['bbox'] = [xmin, ymin, xmax, ymax]
                
                handsData.append(hand)
        return handsData

if __name__ == "__main__":
    # This will only run if track_hand.py is executed directly
    cap = cv2.VideoCapture(0)
    detector = handDetector(maxHands=2)
    
    while True:
        success, img = cap.read()
        img = detector.findHands(img)
        handsData = detector.getMultiHandData(img)
        
        for i, hand in enumerate(handsData):
            cv2.putText(img, f"Hand {i+1}: {sum(hand['fingers'])} fingers", 
                       (10, 50 + i*30), cv2.FONT_HERSHEY_PLAIN, 2, (255,0,255), 2)
        
        cv2.imshow("Hand Tracking", img)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
            
    cap.release()
    cv2.destroyAllWindows()