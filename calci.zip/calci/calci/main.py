# importing librarys
import cv2
import numpy as npy
import face_recognition as face_rec
# function
def resize(img, size) :
    width = int(img.shape[1]*size)
    height = int(img.shape[0] * size)
    dimension = (width, height)
    return cv2.resize(img, dimension, interpolation= cv2.INTER_AREA)


# img declaration
suchita = face_rec.load_image_file('train_faces\suchita.jpg')
suchita = cv2.cvtColor(suchita, cv2.COLOR_BGR2RGB)
suchita = resize(suchita, 0.50)
suchita_test = face_rec.load_image_file('train_faces\suchita_test.jpg')
suchita_test = resize(suchita_test, 0.50)
suchita_test = cv2.cvtColor(suchita_test, cv2.COLOR_BGR2RGB)

# finding face location

faceLocation_suchita = face_rec.face_locations(suchita)[0]
encode_suchita = face_rec.face_encodings(suchita)[0]
cv2.rectangle(suchita, (faceLocation_suchita[3], faceLocation_suchita[0]), (faceLocation_suchita[1], faceLocation_suchita[2]), (255, 0, 255), 3)


faceLocation_suchitatest = face_rec.face_locations(suchita_test)[0]
encode_suchitatest = face_rec.face_encodings(suchita_test)[0]
cv2.rectangle(suchita_test, (faceLocation_suchitatest[3], faceLocation_suchitatest[0]), (faceLocation_suchitatest[1], faceLocation_suchitatest[2]), (255, 0, 255), 3)

results = face_rec.compare_faces([encode_suchita], encode_suchitatest)
print(results)
cv2.putText(suchita_test, f'{results}', (50,50), cv2.FONT_HERSHEY_COMPLEX, 1,(0,0,255), 2 )

cv2.imshow('main_img', suchita)
cv2.imshow('test_img', suchita_test)
cv2.waitKey(0)
cv2.destroyAllWindows()