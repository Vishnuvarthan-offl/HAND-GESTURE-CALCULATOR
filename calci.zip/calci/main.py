import cv2
import numpy as np
import face_recognition as face_rec
import tkinter as tk
import os
import sys
import time

def resize(img, scale=0.5):
    return cv2.resize(img, (0, 0), fx=scale, fy=scale)

# Load and encode known faces
def load_face(name):
    img_path = f"train_faces/{name.lower()}.jpg"
    image = face_rec.load_image_file(img_path)
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    encoding = face_rec.face_encodings(image)[0]
    return encoding

known_names = ["Suchita", "Vishnu", "Sarvanan"]
known_encodings = [load_face(name) for name in known_names]

# Webcam init
cap = cv2.VideoCapture(0)
frame_count = 0
process_rate = 3
popup_shown = False
face_identified = False
recognized_name = ""
pause_started = False
pause_start_time = 0

def show_popup(name):
    def on_yes():
        root.destroy()
        os.system("python python_hand_gesture_calculator.py")

    def on_no():
        root.destroy()
        print("Thank you for using the app!")
        sys.exit()

    root = tk.Tk()
    root.title("Welcome")
    tk.Label(root, text=f"Welcome {name}! Ready to use the calculator?", font=("Arial", 14)).pack(pady=20)
    tk.Button(root, text="Yes", command=on_yes, width=20, height=2).pack(pady=10)
    tk.Button(root, text="No", command=on_no, width=20, height=2).pack(pady=10)
    root.mainloop()

while True:
    ret, frame = cap.read()
    if not ret:
        break

    small_frame = resize(frame, scale=0.25)
    rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)

    if frame_count % process_rate == 0 and not face_identified:
        face_locations = face_rec.face_locations(rgb_small_frame)
        face_encodings = face_rec.face_encodings(rgb_small_frame, face_locations)

        for face_encoding, face_location in zip(face_encodings, face_locations):
            matches = face_rec.compare_faces(known_encodings, face_encoding)
            face_distances = face_rec.face_distance(known_encodings, face_encoding)
            best_match = np.argmin(face_distances)

            if matches[best_match]:
                name = known_names[best_match]
                top, right, bottom, left = face_location
                top *= 4
                right *= 4
                bottom *= 4
                left *= 4

                cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
                cv2.putText(frame, f"Welcome {name}", (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

                face_identified = True
                recognized_name = name
                pause_started = True
                pause_start_time = time.time()
                break
            else:
                cv2.putText(frame, "Face not found", (30, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

    elif face_identified and pause_started:
        elapsed = time.time() - pause_start_time
        cv2.putText(frame, f"Welcome {recognized_name}", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 255, 0), 3)
        if elapsed >= 5 and not popup_shown:
            popup_shown = True
            cap.release()
            cv2.destroyAllWindows()
            show_popup(recognized_name)
            break

    elif not face_identified:
        cv2.putText(frame, "Face not found", (30, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

    cv2.imshow("Face Recognition", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
    frame_count += 1

cap.release()
cv2.destroyAllWindows()
