import cv2
import numpy as np
import track_hand as htm
import time
import re
import math
import random

# Camera Setup
wCam, hCam = 1280, 720
cap = cv2.VideoCapture(0)
cap.set(3, wCam)
cap.set(4, hCam)

# Hand Detector
detector = htm.handDetector(detectionCon=0.7, maxHands=2)

# Variables for Menu & Modes
mode = "menu"  # 'menu', 'calculator', or 'rps'
selected_option = None
menu_selected_time = 0
menu_debounce_delay = 2  # seconds to confirm selection

# Calculator Variables
expression = ""
last_input_time = 0
debounce_delay = 1
result = ""
prev_gesture = None

# RPS Variables
rps_started = False
rps_user_choice = None
rps_ai_choice = None
rps_result = ""

def is_valid_expression(expr):
    try:
        if not re.match(r'^[\d+\-*/().a-zA-Z]+$', expr):
            return False
        if '/0' in expr:
            return False
        if any(op in expr for op in ['++', '--', '**', '//', '*/', '/*']):
            return False
        return True
    except:
        return False

def get_gesture(hands_data):
    if len(hands_data) == 1:
        fingers = hands_data[0]['fingers']
        total = sum(fingers)

        # Menu gestures
        if total == 1: return "1"
        elif total == 2: return "2"

        # Calculator gestures
        if fingers == [1, 0, 0, 0, 1]: return "+"
        elif fingers == [0, 1, 1, 0, 1]: return "-"
        elif fingers == [1, 1, 0, 0, 1]: return "*"
        elif fingers == [0, 0, 0, 0, 1]: return "/"
        elif fingers == [0, 0, 1, 0, 0]: return "="
        elif fingers == [0, 0, 0, 1, 0]: return "C"
        elif fingers == [1, 0, 1, 0, 1]: return "DEL"
        elif fingers == [1, 1, 1, 0, 0]: return "sin"
        elif fingers == [0, 1, 1, 1, 0]: return "cos"
        elif fingers == [1, 0, 0, 1, 1]: return "bin"
        elif fingers == [0, 1, 0, 1, 1]: return "dec"
        elif fingers == [1, 1, 1, 1, 0]: return "sqrt"

    elif len(hands_data) == 2:
        total_fingers = sum(hands_data[0]['fingers']) + sum(hands_data[1]['fingers'])
        if total_fingers == 10:
            return "0"
        elif 1 <= total_fingers <= 9:
            return str(total_fingers)

    return None

def run_calculator(gesture):
    global expression, result, last_input_time, prev_gesture
    current_time = time.time()
    if gesture and gesture != prev_gesture:
        if (current_time - last_input_time) > debounce_delay:
            if gesture == "=":
                try:
                    expr = expression
                    expr = expr.replace("sin", "math.sin(math.radians(").replace("cos", "math.cos(math.radians(")
                    expr = expr.replace("sqrt", "math.sqrt(")
                    expr += ")" * (expr.count("(") - expr.count(")"))
                    if is_valid_expression(expr):
                        result = str(round(eval(expr), 4))
                        expression = result
                    else:
                        result = "Error"
                except:
                    result = "Error"
                    expression = ""
            elif gesture == "C":
                expression = ""
                result = ""
            elif gesture == "DEL":
                expression = expression[:-1]
            elif gesture == "bin":
                try:
                    result = bin(int(float(expression)))
                    expression = result
                except:
                    result = "Error"
                    expression = ""
            elif gesture == "dec":
                try:
                    result = str(int(expression, 2))
                    expression = result
                except:
                    result = "Error"
                    expression = ""
            elif gesture in ['+', '-', '*', '/', 'sin', 'cos', 'sqrt']:
                if expression and expression[-1] in '+-*/':
                    expression = expression[:-1] + gesture
                else:
                    expression += gesture
            else:
                expression += gesture
            prev_gesture = gesture
            last_input_time = current_time

def run_rps(gesture):
    global rps_started, rps_user_choice, rps_ai_choice, rps_result

    if not rps_started:
        rps_started = True
        rps_ai_choice = random.choice(["Rock", "Paper", "Scissors"])

        if gesture == [0, 0, 0, 0, 0]:  # Rock
            rps_user_choice = "Rock"
        elif gesture == [1, 1, 1, 1, 1]:  # Paper
            rps_user_choice = "Paper"
        elif gesture == [0, 1, 1, 0, 0]:  # Scissors
            rps_user_choice = "Scissors"
        else:
            rps_user_choice = "Unknown"

        if rps_user_choice == rps_ai_choice:
            rps_result = "Draw"
        elif (rps_user_choice == "Rock" and rps_ai_choice == "Scissors") or \
             (rps_user_choice == "Paper" and rps_ai_choice == "Rock") or \
             (rps_user_choice == "Scissors" and rps_ai_choice == "Paper"):
            rps_result = "You Win!"
        else:
            rps_result = "You Lose!"

while True:
    success, img = cap.read()
    if not success:
        print("Camera error")
        continue

    img = detector.findHands(img)
    hands_data = detector.getMultiHandData(img)

    # Menu Mode
    if mode == "menu":
        cv2.putText(img, "Select Option using Gesture:", (50, 50),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.2, (255, 255, 255), 2)
        cv2.putText(img, "1: Hand Gesture Calculator", (100, 120),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        cv2.putText(img, "2: Rock Paper Scissors", (100, 170),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)

        gesture = get_gesture(hands_data)
        if gesture in ["1", "2"]:
            if selected_option != gesture:
                selected_option = gesture
                menu_selected_time = time.time()
            elif time.time() - menu_selected_time > menu_debounce_delay:
                if selected_option == "1":
                    mode = "calculator"
                elif selected_option == "2":
                    mode = "rps"
                selected_option = None

    elif mode == "calculator":
        gesture = get_gesture(hands_data)
        run_calculator(gesture)

        # Draw calculator UI
        cv2.putText(img, f"Expression: {expression}", (50, 50),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        cv2.putText(img, f"Result: {result}", (50, 100),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        if gesture:
            cv2.putText(img, f"Gesture: {gesture}", (50, 150),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

    elif mode == "rps":
        if hands_data:
            fingers = hands_data[0]['fingers']
            run_rps(fingers)

        cv2.putText(img, f"Your Choice: {rps_user_choice}", (50, 100),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        cv2.putText(img, f"AI Choice: {rps_ai_choice}", (50, 150),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
        cv2.putText(img, f"Result: {rps_result}", (50, 200),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 255, 0), 3)

    cv2.imshow("Gesture System", img)
    key = cv2.waitKey(1) & 0xFF
    if key == ord('q') or key == 27:
        break

cap.release()
cv2.destroyAllWindows()
