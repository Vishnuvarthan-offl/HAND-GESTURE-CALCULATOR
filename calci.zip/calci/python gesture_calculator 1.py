import cv2
import mediapipe as mp
import math

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=1, min_detection_confidence=0.7)
mp_draw = mp.solutions.drawing_utils

cap = cv2.VideoCapture(0)

expression = ""
result = ""

def count_fingers(hand_landmarks):
    fingers = []

    # Thumb
    if hand_landmarks.landmark[mp_hands.HandLandmark.THUMB_TIP].x < hand_landmarks.landmark[mp_hands.HandLandmark.THUMB_IP].x:
        fingers.append(1)
    else:
        fingers.append(0)

    # 4 fingers
    tips_ids = [mp_hands.HandLandmark.INDEX_FINGER_TIP,
                mp_hands.HandLandmark.MIDDLE_FINGER_TIP,
                mp_hands.HandLandmark.RING_FINGER_TIP,
                mp_hands.HandLandmark.PINKY_TIP]

    pip_ids = [mp_hands.HandLandmark.INDEX_FINGER_PIP,
               mp_hands.HandLandmark.MIDDLE_FINGER_PIP,
               mp_hands.HandLandmark.RING_FINGER_PIP,
               mp_hands.HandLandmark.PINKY_PIP]

    for tip, pip in zip(tips_ids, pip_ids):
        if hand_landmarks.landmark[tip].y < hand_landmarks.landmark[pip].y:
            fingers.append(1)
        else:
            fingers.append(0)

    return fingers.count(1)

import time

last_gesture_time = 0
cooldown = 1.2  # seconds between recognizing same gesture

while True:
    ret, frame = cap.read()
    frame = cv2.flip(frame, 1)
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    result_mp = hands.process(rgb_frame)

    current_time = time.time()

    if result_mp.multi_hand_landmarks:
        for hand_landmarks in result_mp.multi_hand_landmarks:
            mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
            finger_count = count_fingers(hand_landmarks)

            if current_time - last_gesture_time > cooldown:
                # Gesture to character mapping
                if finger_count == 0:  # Fist = Evaluate
                    try:
                        eval_exp = expression.rstrip("+-*/")
                        result = str(eval(eval_exp))
                        expression = result
                    except:
                        result = "Error"
                        expression = ""
                    last_gesture_time = current_time
                elif finger_count == 1:
                    expression += "1"
                    last_gesture_time = current_time
                elif finger_count == 2:
                    expression += "+"
                    last_gesture_time = current_time
                elif finger_count == 3:
                    expression += "-"
                    last_gesture_time = current_time
                elif finger_count == 4:
                    expression += "*"
                    last_gesture_time = current_time
                elif finger_count == 5:
                    expression += "/"
                    last_gesture_time = current_time

                # Thumb-only clear gesture
                thumb_tip = hand_landmarks.landmark[mp_hands.HandLandmark.THUMB_TIP]
                thumb_ip = hand_landmarks.landmark[mp_hands.HandLandmark.THUMB_IP]
                index_tip = hand_landmarks.landmark[mp_hands.HandLandmark.INDEX_FINGER_TIP]

                if (thumb_tip.y < thumb_ip.y) and (index_tip.y > thumb_ip.y):  # Only thumb up
                    expression = ""
                    result = ""
                    last_gesture_time = current_time


cap.release()
cv2.destroyAllWindows()
